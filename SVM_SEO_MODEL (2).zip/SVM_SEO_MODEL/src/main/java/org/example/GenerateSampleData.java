package org.example;


import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class GenerateSampleData {

    public static void main(String[] args) {
        String csvFile = "sample_data.csv";

        try (FileWriter writer = new FileWriter(csvFile)) {
            // Write header
           // Generate and write 1000 data points
            Random random = new Random();
            for (int i = 0; i < 1000; i++) {
                double x = random.nextDouble() * 10; // Random X between 0 and 10
                double y = random.nextDouble() * 10; // Random Y between 0 and 10

                writer.append(String.format("%.2f,%.2f\n", x, y));
            }

            System.out.println("Sample data generated and saved to " + csvFile);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
