package org.example;

import libsvm.*;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class GenerateDataFor90PercentAccuracy {
    public static void main(String[] args) {
        // Generate synthetic data and save it to a CSV file
        String csvFile = "generated_data.csv";
        generateData(csvFile);

        // Use the generated data to train an SVM model and aim for 90% accuracy
        // ... (training and evaluation code)
    }

    private static void generateData(String csvFile) {
        try (FileWriter writer = new FileWriter(csvFile)) {
            writer.append("X,Y,Label\n");

            Random random = new Random();
            int totalSamples = 1000; // Total number of samples
            int samplesForClass1 = (int) (totalSamples * 0.5); // 50% for each class
            int samplesForClass2 = totalSamples - samplesForClass1;

            // Generate data for Class 1 (positive class)
            for (int i = 0; i < samplesForClass1; i++) {
                // Generate data with good separation
                double xClass1 = random.nextDouble() * 3; // Class 1 data, X in [0, 3)
                double yClass1 = random.nextDouble() * 3; // Class 1 data, Y in [0, 3)
                writer.append(String.format("%.2f,%.2f,1\n", xClass1, yClass1));
            }

            // Generate data for Class 2 (negative class)
            for (int i = 0; i < samplesForClass2; i++) {
                // Generate data with good separation but overlap to some extent
                double xClass2 = 5 + random.nextDouble() * 3; // Class 2 data, X in [5, 8)
                double yClass2 = 5 + random.nextDouble() * 3; // Class 2 data, Y in [5, 8)
                writer.append(String.format("%.2f,%.2f,2\n", xClass2, yClass2));
            }

            System.out.println("Synthetic data generated and saved to " + csvFile);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

