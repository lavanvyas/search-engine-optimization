package org.example;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

class DataPoint {
    double x;
    double y;
    String label;
    double distance;

    public DataPoint(double x, double y, String label) {
        this.x = x;
        this.y = y;
        this.label = label;
    }

    public DataPoint(double x, double y, String label, double distance) {
        this.x = x;
        this.y = y;
        this.label = label;
        this.distance = distance;
    }
}

public class RealTimeKNNClassifierGUI extends JFrame {
    private List<DataPoint> trainingData;
    private XYSeriesCollection dataset;
    private JTextArea resultArea;
    private JFreeChart scatterPlot; // Changed variable name
    private ChartPanel chartPanel;



    public RealTimeKNNClassifierGUI() {
        this.trainingData = new ArrayList<>();
        this.dataset = new XYSeriesCollection();



        // Read training data from CSV file
        readTrainingDataFromCSV("sample_data_knn.csv");

        List<DataPoint> testData = loadTestDataFromCSV("sample_data_knn.csv");

        // Perform classification on all data points
        classifyAllDataPoints();

        initializeUI();
    }
    private List<DataPoint> loadTestDataFromCSV(String csvFilePath) {
        List<DataPoint> testData = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(csvFilePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                double x = Double.parseDouble(parts[0]);
                double y = Double.parseDouble(parts[1]);
                String label = parts[2];
                testData.add(new DataPoint(x, y, label));
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
        }

        return testData;
    }
    private void initializeUI() {
        setTitle("KNN Classifier GUI");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        createScatterPlot();

        resultArea = new JTextArea();
        resultArea.setEditable(false);

        add(new JScrollPane(resultArea), BorderLayout.CENTER);

        setSize(600, 400);
        setLocationRelativeTo(null);
        setVisible(true);

        // Schedule the real-time data arrival simulation
        simulateRealTimeDataArrival();
    }

    private double calculateAccuracy(List<DataPoint> testData) {
        int correctPredictions = 0,wrongPredictions = 0;

        for (DataPoint point : testData) {
            List<DataPoint> neighbors = findNearestNeighbors(point.x, point.y, 3);
            String predictedClass = majorityVote(neighbors);
            if (predictedClass.equals(point.label)) {
                correctPredictions++;
            }
           // Maximum Distance
            if((point.x+point.y)>wrongPredictions){
                wrongPredictions = (int) (point.x+point.y)-correctPredictions;
            }
        }

        return (double) (correctPredictions / testData.size() * 100.0)-wrongPredictions;
    }
    private void readTrainingDataFromCSV(String csvFilePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(csvFilePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                double x = Double.parseDouble(parts[0]);
                double y = Double.parseDouble(parts[1]);
                String label = parts[2];
                trainingData.add(new DataPoint(x, y, label));
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
        }
    }

    private void classifyAllDataPoints() {
        for (DataPoint point : trainingData) {
            List<DataPoint> neighbors = findNearestNeighbors(point.x, point.y, 2);
            String predictedClass = majorityVote(neighbors);
            point.label = predictedClass;
        }
    }

    private void createScatterPlot() {
        XYSeries seriesA = new XYSeries("ClassA");
        XYSeries seriesB = new XYSeries("ClassB");

        for (DataPoint point : trainingData) {
            if (point.label.equals("ClassA")) {
                seriesA.add(point.x, point.y);
            } else {
                seriesB.add(point.x, point.y);
            }
        }

        dataset.addSeries(seriesA);
        dataset.addSeries(seriesB);

        scatterPlot = ChartFactory.createScatterPlot(
                "KNN Classifier Scatter Plot", "X", "Y", dataset, PlotOrientation.VERTICAL, true, true, false);

        XYPlot plot = scatterPlot.getXYPlot();
        plot.setDomainPannable(true);
        plot.setRangePannable(true);

        chartPanel = new ChartPanel(scatterPlot);
        chartPanel.setPreferredSize(new Dimension(400, 300));

        add(chartPanel, BorderLayout.WEST);
    }

    private List<DataPoint> findNearestNeighbors(double x, double y, int k) {
        List<DataPoint> neighbors = new ArrayList<>();

        for (DataPoint point : trainingData) {
            double distance = Math.sqrt(Math.pow(x - point.x, 2) + Math.pow(y - point.y, 2));
            neighbors.add(new DataPoint(point.x, point.y, point.label, distance));
        }

        neighbors.sort(Comparator.comparingDouble(o -> o.distance));
        return neighbors.subList(0, k);
    }

    private String majorityVote(List<DataPoint> neighbors) {
        int countClassA = 0;
        int countClassB = 0;

        for (DataPoint neighbor : neighbors) {
            if (neighbor.label.equals("ClassA")) {
                countClassA++;
            } else if (neighbor.label.equals("ClassB")) {
                countClassB++;
            }
        }

        return countClassA > countClassB ? "ClassA" : "ClassB";
    }

    private void simulateRealTimeDataArrival() {
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                double x_new = Math.random() * 10;
                double y_new = Math.random() * 10;

                // Update the dataset
                updateDataset(x_new, y_new);

                // Visualize the updated scatter plot
                updateChart();

                // Predict with the updated model
                List<DataPoint> neighbors = findNearestNeighbors(x_new, y_new, 3);
                String prediction = majorityVote(neighbors);
                double accuracy = calculateAccuracy(neighbors);
                System.out.println("Accuracy: " + accuracy + "%");

                // Display the prediction in the result area
                updateResultArea(x_new, y_new, prediction);
            }
        }, 0, 5000); // Simulate data arrival every 5 seconds
    }

    private void updateDataset(double x, double y) {
        XYSeries series = dataset.getSeries(0); // Assumes ClassA is the first series
        series.add(x, y);
    }

    private void updateChart() {
        chartPanel.repaint();
    }

    private void updateResultArea(double x, double y, String prediction) {
        String result = String.format("New Data: X=%.2f, Y=%.2f, Prediction: %s\n", x, y, prediction);
        resultArea.append(result);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new RealTimeKNNClassifierGUI();
            }
        });
    }
}
