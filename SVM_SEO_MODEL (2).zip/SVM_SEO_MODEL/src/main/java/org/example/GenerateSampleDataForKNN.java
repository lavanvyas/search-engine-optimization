package org.example;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class GenerateSampleDataForKNN {
    public static void main(String[] args) {
        String csvFile = "test_data_knn.csv";
        generateSampleData(csvFile);
    }

    private static void generateSampleData(String csvFile) {
        try (FileWriter writer = new FileWriter(csvFile)) {
            writer.append("X,Y,Label\n");

            Random random = new Random();
            int totalSamples = 200; // Total number of samples
            int samplesForClassA = totalSamples / 2; // Half for each class
            int samplesForClassB = totalSamples - samplesForClassA;

            // Generate data for Class A
            for (int i = 0; i < samplesForClassA; i++) {
                double x = random.nextDouble() * 5; // Class A data, X in [0, 5)
                double y = random.nextDouble() * 5; // Class A data, Y in [0, 5)
                writer.append(String.format("%.2f,%.2f,ClassA\n", x, y));
            }

            // Generate data for Class B
            for (int i = 0; i < samplesForClassB; i++) {
                double x = 5 + random.nextDouble() * 5; // Class B data, X in [5, 10)
                double y = 5 + random.nextDouble() * 5; // Class B data, Y in [5, 10)
                writer.append(String.format("%.2f,%.2f,ClassB\n", x, y));
            }

            System.out.println("Sample data generated and saved to " + csvFile);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

