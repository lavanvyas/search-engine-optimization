package org.example;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class SampleDataGeneratorKNN {
    public static void main(String[] args) {
        generateSampleData("sample_data_knn.csv", 1000); // Change the path and number of data points as needed
    }

    private static void generateSampleData(String filePath, int numDataPoints) {
        try (FileWriter writer = new FileWriter(filePath)) {
            // Write header
            writer.write("X,Y,Label\n");

            // Generate and write random data points
            Random random = new Random();
            for (int i = 0; i < numDataPoints; i++) {
                double x = random.nextDouble() * 10; // Adjust the range as needed
                double y = random.nextDouble() * 10;
                String label = (random.nextBoolean()) ? "ClassA" : "ClassB";

                // Write data point to CSV file
                writer.write(String.format("%.2f,%.2f,%s\n", x, y, label));
            }

            System.out.println("Sample data generated and written to: " + filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
