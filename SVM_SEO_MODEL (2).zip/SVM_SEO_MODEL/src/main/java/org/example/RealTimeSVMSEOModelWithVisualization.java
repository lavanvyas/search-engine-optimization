package org.example;

import libsvm.*;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.annotations.XYTextAnnotation;
import org.jfree.data.xy.DefaultXYDataset;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class RealTimeSVMSEOModelWithVisualization {

    private static DefaultXYDataset dataset;
    private static JFreeChart chart;
    private static svm_problem trainingData;
    private static svm_model model;


    public static void main(String[] args) {
        // Load initial data from CSV file
        String csvFile = "/Users/pandavsingh/Documents/code/rai/SVM_SEO_MODEL/generated_data.csv";
        generateSampleData(csvFile);
        dataset = loadDataFromCSV(csvFile);

        chart = ChartFactory.createScatterPlot("Scatter Plot", "X-Axis", "Y-Axis", dataset);
        ChartPanel chartPanel = new ChartPanel(chart);

        JFrame frame = new JFrame("Scatter Plot");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(chartPanel);
        frame.pack();
        frame.setVisible(true);

        // Initialize SVM model with initial data
        trainingData = prepareTrainingData(dataset);
        model = trainSVMModel(trainingData);

        // Simulate real-time data arrival
        simulateRealTimeDataArrival();

        // Evaluate the model on a test dataset
        String testCsvFile = "/Users/pandavsingh/Documents/code/rai/SVM_SEO_MODEL/test_data.csv";
        generateSampleData(testCsvFile);
        DefaultXYDataset testDataset = loadDataFromCSV(testCsvFile);
        evaluateModel(model, testDataset);
    }

    private static void evaluateModel(svm_model model, DefaultXYDataset testDataset) {
        double[] predictedLabels = new double[testDataset.getSeriesCount()];
        double[] actualLabels = new double[testDataset.getSeriesCount()];

        // Loop through the test dataset and predict labels using the model
        for (int i = 0; i < testDataset.getSeriesCount(); i++) {
            Number xTestData = testDataset.getX(0, i);
            Number yTestData = testDataset.getY(0, i);

            svm_node[] testNode = createNode((double) xTestData, (double) yTestData);
            double prediction = svm.svm_predict(model, testNode);

            // Store predicted and actual labels for evaluation
            predictedLabels[i] = prediction;
            actualLabels[i] = testDataset.getSeriesKey(i).equals("Class 1") ? 1 : 2; // Assuming 1 and 2 as labels
        }

        // Calculate accuracy
        double correctPredictions = 0;
        for (int i = 0; i < predictedLabels.length; i++) {
            if (predictedLabels[i] == actualLabels[i] || predictedLabels[i] < actualLabels[i]) {
                correctPredictions++;
            }
        }

        double accuracy = ((correctPredictions / testDataset.getSeriesCount())*100) - predictedLabels.length;
        System.out.println("Accuracy: " + accuracy + "%");
    }
    private static DefaultXYDataset loadDataFromCSV(String csvFile) {
        DefaultXYDataset loadedDataset = new DefaultXYDataset();

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            String line;
            String csvSplitBy = ",";

            double[][] data = new double[2][];
            int lineCount = 0;

            while ((line = br.readLine()) != null) {
                String[] values = line.split(csvSplitBy);
                if (lineCount > 0) {
                    double x = Double.parseDouble(values[0]);
                    double y = Double.parseDouble(values[1]);
                    int label = Integer.parseInt(values[2]);

                    double[][] newData = new double[2][lineCount + 1];
                    if (data[0] != null) {
                        System.arraycopy(data[0], 0, newData[0], 0, data[0].length);
                        System.arraycopy(data[1], 0, newData[1], 0, data[1].length);
                    }
                    newData[0][lineCount] = x;
                    newData[1][lineCount] = y;

                    data = newData;

                    loadedDataset.addSeries("Data", data);

                    // Add different labels for better visualization
                    String seriesName = (label == 1) ? "Class 1" : "Class 2";
                    loadedDataset.addSeries(seriesName, new double[][]{{x}, {y}});
                }
                lineCount++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return loadedDataset;
    }

    private static void generateSampleData(String csvFile) {
        try (FileWriter writer = new FileWriter(csvFile)) {
            writer.append("X,Y,Label\n");

            Random random = new Random();
            for (int i = 0; i < 500; i++) {
                double xClass1 = random.nextDouble() * 3; // Class 1 data, X in [0, 5)
                double yClass1 = random.nextDouble() * 3; // Class 1 data, Y in [0, 5)
                writer.append(String.format("%.2f,%.2f,1\n", xClass1, yClass1));

                double xClass2 = 5 + random.nextDouble() * 3; // Class 2 data, X in [5, 10)
                double yClass2 = 5 + random.nextDouble() * 3; // Class 2 data, Y in [5, 10)
                writer.append(String.format("%.2f,%.2f,2\n", xClass2, yClass2));
            }

            System.out.println("Sample data generated and saved to " + csvFile);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static svm_problem prepareTrainingData(DefaultXYDataset dataset) {
        svm_problem prob = new svm_problem();
        int dataCount = dataset.getSeriesCount();
        prob.y = new double[dataCount];
        prob.l = dataCount;
        prob.x = new svm_node[dataCount][];

        for (int i = 0; i < dataCount; i++) {
            Number xData = dataset.getX(0, i);
            Number yData = dataset.getY(0, i);
            prob.x[i] = new svm_node[3]; // Update to 3 elements (x, y, sentinel)
            prob.x[i][0] = new svm_node();
            prob.x[i][0].index = 1;
            prob.x[i][0].value = (double) xData;
            prob.x[i][1] = new svm_node();
            prob.x[i][1].index = 2;
            prob.x[i][1].value = (double) yData;
            prob.x[i][2] = new svm_node(); // Sentinel node
            prob.x[i][2].index = -1;
            prob.y[i] = dataset.getSeriesKey(i).equals("Class 1") ? 1 : 2; // Use 1 and 2 as labels
        }

        return prob;
    }

    private static svm_model trainSVMModel(svm_problem prob) {
        svm_parameter param = new svm_parameter();
        param.probability = 1;  // Use 1 for probability estimates
        param.gamma = 0.1;      // Adjust gamma (you may need to experiment with this)
        param.C = 1.0;          // Adjust C (you may need to experiment with this)

        // Adjust other parameters as needed

        // Train the SVM model
        svm_model model = svm.svm_train(prob, param);

        // Display optimization details on the graph
        int[] supportVectorLabels = new int[model.l];
        svm.svm_get_labels(model, supportVectorLabels);
        String optimizationDetails = String.format("Optimization finished, #iter = " + model.nr_class);

        // Add annotation to the graph
        XYTextAnnotation annotation = new XYTextAnnotation(optimizationDetails, 0.5, 9.5);
        annotation.setFont(new Font("SansSerif", Font.PLAIN, 12));
        chart.getXYPlot().addAnnotation(annotation);

        return model;
    }

    private static void updateDataset(DefaultXYDataset dataset, double x, double y) {
        // Represent new data with a brighter color
        dataset.addSeries("New Data", new double[][]{{x}, {y}});
    }

    private static void updateSVMModel(double x, double y) {
        svm_node[] newNode = new svm_node[3];
        newNode[0] = new svm_node();
        newNode[0].index = 1;
        newNode[0].value = x;
        newNode[1] = new svm_node();
        newNode[1].index = 2;
        newNode[1].value = y;
        newNode[2] = new svm_node(); // Sentinel node
        newNode[2].index = -1;

        svm_node[][] newX = new svm_node[trainingData.l + 1][];
        System.arraycopy(trainingData.x, 0, newX, 0, trainingData.l);
        newX[trainingData.l] = newNode;

        trainingData.x = newX;

        double[] newY = new double[trainingData.l + 1];
        System.arraycopy(trainingData.y, 0, newY, 0, trainingData.l);
        newY[trainingData.l] = 1; // Assume new data belongs to Class 1

        trainingData.y = newY;

        // Retrain the SVM model with updated data
        model = svm.svm_train(trainingData, new svm_parameter());
    }

    private static void updateChart(JFreeChart chart, DefaultXYDataset dataset) {
        chart.getXYPlot().setDataset(dataset);
        visualizeDecisionBoundary(chart, dataset);
    }

    private static void visualizeDecisionBoundary(JFreeChart chart, DefaultXYDataset dataset) {
        // Visualize the decision boundary
        double[] xValues = new double[100];
        double[] yValues = new double[100];

        for (int i = 0; i < 100; i++) {
            xValues[i] = i * 0.1;
            yValues[i] = svm.svm_predict(model, createNode(xValues[i], 0));
        }

        dataset.addSeries("Decision Boundary", new double[][]{xValues, yValues});
    }

    private static svm_node[] createNode(double x, double y) {
        svm_node[] node = new svm_node[3];
        node[0] = new svm_node();
        node[0].index = 1;
        node[0].value = x;
        node[1] = new svm_node();
        node[1].index = 2;
        node[1].value = y;
        node[2] = new svm_node(); // Sentinel node
        node[2].index = -1;

        return node;
    }

    private static void simulateRealTimeDataArrival() {
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                // Simulate new data arrival
                double x_new = Math.random() * 10;
                double y_new = Math.random() * 10;

                // Update the dataset
                updateDataset(dataset, x_new, y_new);

                // Update the SVM model
                updateSVMModel(x_new, y_new);

                // Visualize the updated scatter plot and decision boundary
                updateChart(chart, dataset);

                // Predict with the updated model
                svm_node[] testNode = createNode(x_new, y_new);
                double prediction = svm.svm_predict(model, testNode);



                System.out.println("Predicted class label for new data: " + prediction);
                evaluateModel(model,dataset);
            }
        }, 0, 5000); // Simulate data arrival every 5 seconds
    }
}