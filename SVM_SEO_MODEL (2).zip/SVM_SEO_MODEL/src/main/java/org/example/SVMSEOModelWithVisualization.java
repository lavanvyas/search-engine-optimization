package org.example;

import libsvm.*;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.xy.DefaultXYDataset;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class SVMSEOModelWithVisualization {

    public static void main(String[] args) {

        // Load data from CSV file
        String csvFile = "/Users/pandavsingh/Documents/code/rai/SVM_SEO_MODEL/sample_data.csv"; // Replace with the path to your actual data file
        String line;
        String csvSplitBy = ",";

        DefaultXYDataset dataset = new DefaultXYDataset();

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            int lineCount = 0;
            double[][] data = new double[2][];
            while ((line = br.readLine()) != null) {
                String[] values = line.split(csvSplitBy);
                if (lineCount > 0) {
                    double x = Double.parseDouble(values[0]);
                    double y = Double.parseDouble(values[1]);

                    double[][] newData = new double[2][lineCount + 1];
                    if (data[0] != null) {
                        System.arraycopy(data[0], 0, newData[0], 0, data[0].length);
                        System.arraycopy(data[1], 0, newData[1], 0, data[1].length);
                    }
                    newData[0][lineCount] = x;
                    newData[1][lineCount] = y;

                    data = newData;

                    dataset.addSeries("Data", data);
                }
                lineCount++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        JFreeChart chart = ChartFactory.createScatterPlot("Scatter Plot", "X-Axis", "Y-Axis", dataset);
        ChartPanel chartPanel = new ChartPanel(chart);

        JFrame frame = new JFrame("Scatter Plot");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(chartPanel);

        // Display the scatter plot
        frame.pack();
        frame.setVisible(true);

        // Prepare data for SVM
        svm_problem prob = new svm_problem();
        int dataCount = dataset.getSeriesCount();
        prob.y = new double[dataCount];
        prob.l = dataCount;
        prob.x = new svm_node[dataCount][];

        for (int i = 0; i < dataCount; i++) {
            Number xData = dataset.getX(0, i);
            Number yData = dataset.getY(0, i);
            prob.x[i] = new svm_node[2];
            prob.x[i][0] = new svm_node();
            prob.x[i][0].index = 1;
            prob.x[i][0].value = (double) xData;
            prob.x[i][1] = new svm_node();
            prob.x[i][1].index = 2;
            prob.x[i][1].value = (double) yData;
            prob.y[i] = 1;
        }

        svm_parameter param = new svm_parameter();
        param.probability = 1;  // Use 1 for probability estimates
        param.gamma = 0.5;
        param.C = 10;

        svm_model model = svm.svm_train(prob, param);

        // Test data for prediction
        double x_test = 3.5; // Sample test x value for prediction
        double y_test = 2.0; // Sample test y value for prediction

        svm_node[] testNode = new svm_node[2];
        testNode[0] = new svm_node();
        testNode[0].index = 1;
        testNode[0].value = x_test;
        testNode[1] = new svm_node();
        testNode[1].index = 2;
        testNode[1].value = y_test;

        double prediction = svm.svm_predict(model, testNode);
        System.out.println("Predicted class label: " + prediction);

        // Evaluate accuracy on training data
        double[] trainLabels = new double[dataCount];
        for (int i = 0; i < dataCount; i++) {
            trainLabels[i] = svm.svm_predict(model, prob.x[i]);
        }
        double trainAccuracy = calculateAccuracy(prob.y, trainLabels);
        System.out.println("Training Accuracy: " + trainAccuracy);

        // Test data for accuracy calculation
        int testDataCount = 5;  // Replace with the actual size of your test dataset
        svm_problem testProb = new svm_problem();
        testProb.y = new double[testDataCount];
        testProb.l = testDataCount;
        testProb.x = new svm_node[testDataCount][];

        // ... (populate testProb.x and testProb.y with test data)

        double[] testLabels = new double[testDataCount];
        for (int i = 0; i < testDataCount; i++) {
            testLabels[i] = svm.svm_predict(model, testProb.x[i]);
        }
        double testAccuracy = calculateAccuracy(testProb.y, testLabels);
        System.out.println("Testing Accuracy: " + testAccuracy);

        // ... (your existing code)
    }

    private static double calculateAccuracy(double[] actualLabels, double[] predictedLabels) {
        int correctCount = 0;
        for (int i = 0; i < actualLabels.length; i++) {
            if (actualLabels[i] == predictedLabels[i]) {
                correctCount++;
            }
        }
        return (double) correctCount / actualLabels.length * 100.0;
    }
}
